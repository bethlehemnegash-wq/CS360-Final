package Weighttrackerapp.bethlehemnegash

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "WeightTracker.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {

        db.execSQL(
            "CREATE TABLE users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT UNIQUE, " +
                    "password TEXT)"
        )

        db.execSQL(
            "CREATE TABLE weights (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "date TEXT, " +
                    "weight REAL, " +
                    "goal REAL)"
        )
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS weights")
        onCreate(db)
    }

    fun insertUser(username: String, password: String): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put("username", username)
        values.put("password", password)

        val result = db.insert("users", null, values)

        return result != -1L
    }

    fun checkUser(username: String, password: String): Boolean {

        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )

        val exists = cursor.count > 0

        cursor.close()

        return exists
    }

    fun insertWeight(
        date: String,
        weight: Double,
        goal: Double
    ): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put("date", date)
        values.put("weight", weight)
        values.put("goal", goal)

        val result = db.insert(
            "weights",
            null,
            values
        )

        return result != -1L
    }

    fun getAllWeights(): Cursor {

        return readableDatabase.rawQuery(
            "SELECT * FROM weights",
            null
        )
    }

    fun updateWeight(
        id: Int,
        date: String,
        weight: Double,
        goal: Double
    ): Boolean {

        val db = writableDatabase
        val values = ContentValues()

        values.put("date", date)
        values.put("weight", weight)
        values.put("goal", goal)

        val result = db.update(
            "weights",
            values,
            "id=?",
            arrayOf(id.toString())
        )

        return result > 0
    }

    fun deleteWeight(id: Int): Boolean {

        val result = writableDatabase.delete(
            "weights",
            "id=?",
            arrayOf(id.toString())
        )

        return result > 0
    }
}