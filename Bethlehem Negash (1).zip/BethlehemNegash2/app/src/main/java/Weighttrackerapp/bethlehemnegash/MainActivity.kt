package Weighttrackerapp.bethlehemnegash

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat

class MainActivity : ComponentActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private var smsPermissionGranted = false
    private val smsPermissionCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        databaseHelper = DatabaseHelper(this)
        showLoginScreen()
    }

    private fun showLoginScreen() {
        setContentView(R.layout.activity_login)

        val usernameField = findViewById<EditText>(R.id.usernameField)
        val passwordField = findViewById<EditText>(R.id.passwordField)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val createAccountButton = findViewById<Button>(R.id.createAccountButton)

        createAccountButton.setOnClickListener {
            val username = usernameField.text.toString()
            val password = passwordField.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                if (databaseHelper.insertUser(username, password)) {
                    Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show()
            }
        }

        loginButton.setOnClickListener {
            val username = usernameField.text.toString()
            val password = passwordField.text.toString()

            if (databaseHelper.checkUser(username, password)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
                showSmsScreen()
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSmsScreen() {
        setContentView(R.layout.activity_sms)

        val allowButton = findViewById<Button>(R.id.allowSmsButton)
        val denyButton = findViewById<Button>(R.id.denySmsButton)
        val statusText = findViewById<TextView>(R.id.permissionStatusText)

        allowButton.setOnClickListener {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                smsPermissionCode
            )
        }

        denyButton.setOnClickListener {
            smsPermissionGranted = false
            statusText.text = "Permission Status: Denied"
            Toast.makeText(this, "App will continue without SMS", Toast.LENGTH_SHORT).show()
            showWeightTrackerScreen()
        }
    }

    private fun showWeightTrackerScreen() {
        setContentView(R.layout.activity_weighttracker)

        val dateField = findViewById<EditText>(R.id.dateField)
        val weightField = findViewById<EditText>(R.id.weightField)
        val goalField = findViewById<EditText>(R.id.goalField)
        val idField = findViewById<EditText>(R.id.idField)

        val addButton = findViewById<Button>(R.id.addButton)
        val updateButton = findViewById<Button>(R.id.updateButton)
        val deleteButton = findViewById<Button>(R.id.deleteButton)

        loadWeightTable()

        addButton.setOnClickListener {
            val date = dateField.text.toString()
            val weight = weightField.text.toString().toDoubleOrNull()
            val goal = goalField.text.toString().toDoubleOrNull()

            if (date.isNotEmpty() && weight != null && goal != null) {
                databaseHelper.insertWeight(date, weight, goal)
                Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT).show()

                if (weight <= goal) {
                    sendGoalSms()
                }

                loadWeightTable()
            } else {
                Toast.makeText(this, "Enter date, weight, and goal", Toast.LENGTH_SHORT).show()
            }
        }

        updateButton.setOnClickListener {
            val id = idField.text.toString().toIntOrNull()
            val date = dateField.text.toString()
            val weight = weightField.text.toString().toDoubleOrNull()
            val goal = goalField.text.toString().toDoubleOrNull()

            if (id != null && date.isNotEmpty() && weight != null && goal != null) {
                if (databaseHelper.updateWeight(id, date, weight, goal)) {
                    Toast.makeText(this, "Entry updated", Toast.LENGTH_SHORT).show()
                    loadWeightTable()
                } else {
                    Toast.makeText(this, "Entry not found", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter ID, date, weight, and goal", Toast.LENGTH_SHORT).show()
            }
        }

        deleteButton.setOnClickListener {
            val id = idField.text.toString().toIntOrNull()

            if (id != null) {
                if (databaseHelper.deleteWeight(id)) {
                    Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show()
                    loadWeightTable()
                } else {
                    Toast.makeText(this, "Entry not found", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter entry ID", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadWeightTable() {
        val table = findViewById<TableLayout>(R.id.weightTable)
        table.removeAllViews()

        val header = TableRow(this)
        header.addView(makeCell("ID"))
        header.addView(makeCell("Date"))
        header.addView(makeCell("Weight"))
        header.addView(makeCell("Goal"))
        table.addView(header)

        val cursor = databaseHelper.getAllWeights()

        while (cursor.moveToNext()) {
            val row = TableRow(this)
            row.addView(makeCell(cursor.getInt(0).toString()))
            row.addView(makeCell(cursor.getString(1)))
            row.addView(makeCell(cursor.getDouble(2).toString()))
            row.addView(makeCell(cursor.getDouble(3).toString()))
            table.addView(row)
        }

        cursor.close()
    }

    private fun makeCell(text: String): TextView {
        val cell = TextView(this)
        cell.text = text
        cell.setPadding(8, 8, 8, 8)
        return cell
    }

    private fun sendGoalSms() {
        if (smsPermissionGranted) {
            try {
                SmsManager.getDefault().sendTextMessage(
                    "5551234567",
                    null,
                    "Congratulations! You reached your goal weight.",
                    null,
                    null
                )

                Toast.makeText(this, "Goal SMS sent", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "SMS could not be sent", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Goal reached. SMS permission not granted.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == smsPermissionCode) {
            smsPermissionGranted =
                grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED

            if (smsPermissionGranted) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS denied. App will still work.", Toast.LENGTH_SHORT).show()
            }

            showWeightTrackerScreen()
        }
    }
}